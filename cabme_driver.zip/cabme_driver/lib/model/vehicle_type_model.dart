class VehicleTypeModel {
  String? icon;
  String? name;

  VehicleTypeModel({this.icon, this.name});
}
