class OnboardingModel {
  late String? imageAsset;
  late String? title;
  late String? description;

  OnboardingModel(this.imageAsset, this.title, this.description);
}
