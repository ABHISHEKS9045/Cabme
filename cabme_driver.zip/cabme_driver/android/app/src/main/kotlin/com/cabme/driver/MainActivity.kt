package com.cabme.driver

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
